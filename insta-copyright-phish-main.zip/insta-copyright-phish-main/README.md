# ig-ct-phish
## recoder : www.instagram.com/mishab_zaya
## Credit For Some Code: github.com/thelinuxchoice
## IG: www.instagram.com/mishab_zaya
## YouTube 1 : https://youtube.com/channel/UChh-IMnXMUfu9I9Q84aLrHg

### Don't copy this code without give us credits, nerd! 
### Instagram webpage made by Malicious (https://github.com/MISHAB-ZAYA)

Phishing Tool for advance instagram copyright infringement attack 

### Features:
### Port Forwarding using Ngrok And Serveo

## Legal disclaimer:

Usage of ig-ct-phish for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program 

## Modify index.html

[1] ctrl+F Target circle image & and give path your target image
[2] ctrl+F (Victim Name) give your victim username


### Usage:
```
git clone https://github.com/MISHAB-ZAYA/ig-ct-phish.git
cd insta-copyright
chmod +x ig-ct-phish.sh
bash ig-ct-phish.sh
```






